export { default } from './FormControlLabel';
export * from './FormControlLabel';
