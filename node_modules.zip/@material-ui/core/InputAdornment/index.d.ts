export { default } from './InputAdornment';
export * from './InputAdornment';
